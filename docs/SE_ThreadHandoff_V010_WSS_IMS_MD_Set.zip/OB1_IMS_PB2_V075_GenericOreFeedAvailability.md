# OB1 IMS PB2 V075 - Generic Ore Feed Availability

## Reason

The V074A temporary diagnostics proved these facts at the same time:

- Stone was physically present in the correct OB1 managed `[ORE*]` bulk cargo (`POOL OREPOOL all=1M ore=1M/1`).
- PB2 could move Stone from that same cargo into a refinery (`TRC ST002 RFILL OK ... -> [OB1] Refinery 1`).
- The old soft/feed count path still reported zero (`feedSoft=0`, `DBG GRV cargo=0`).

That means the issue was not LDC1, not missing Stone, and not a Stone-only destination leak. The no-feed/noWanted state came from the refinery ore-selection availability path being able to report no available ore even when the managed ore pool contained Stone.

## Fix

This patch keeps the V070 Stone -> Gravel demand mapping, removes the temporary diagnostics, and changes the optimized refinery candidate selection to scan the managed cargo ore pool directly once rather than asking `CountOreInManagedCargo()` once per ore name.

This is a generic refinery-feed availability fix, not a Stone-only hack.

## Code changes

- `FindBestOreForRefinery()` now scans `managedCargo` inventories directly.
- Each ore item found is normalized with existing `OreName()`.
- Candidate ore names must be present in `ORE_NAMES` through new helper `TrackedOre()`.
- Existing `OreAllowedForRefinery()`, `AdjustedOreScore()`, high-value/yield rules, and Stone/Gravel demand mapping remain in force.
- `HasOtherNeededOreForRefinery()` now includes the full `ORE_NAMES` list instead of skipping the last entry, so Stone is not silently excluded from “other needed ore” checks.

## Removed

- All temporary V073/V074A diagnostics.
- Stone trace echo.
- Ore pool diagnostic echo.

## Test

1. Load `OB1_IMS_PB2_V075_GenericOreFeedAvailability.cs`.
2. Recompile.
3. Keep PB1 Gravel below minimum and Stone in OB1 `[ORE*]` managed cargo.
4. Wait for optimized refinery cycle.
5. Expected Echo:
   - `R ... Stone +...`, `R ... topoff Stone +...`, or `R ... keep Stone`
   - no `DBG GRV`, `TRC STONE`, or `POOL OREPOOL` lines.
6. Confirm Stone stays in OB1 managed cargo/refineries and does not migrate to LDC1.
